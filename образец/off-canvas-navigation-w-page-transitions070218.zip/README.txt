A Pen created at CodePen.io. You can find this one at https://codepen.io/kjbrum/pen/VQjGvJ.

 More experimentation with transitions and navigation. Decided to add in a little bit for page transitions as well.